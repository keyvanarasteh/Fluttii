package com.example.fluttiiticaret

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
